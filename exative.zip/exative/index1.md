# w02-design-your-own-template-Batterryz
## id 6014421002
## Bat Chanthimatorn
## email 6014421002@rbru.ac.th

(web stie)
(http://stu2.rbru.ac.th/~s6014421002)


<!DOCTYPE html>
<!--
Template Name: Exative
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
<head>
<title>BATMASTER</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="fl_left">
      <ul>
        <li><i class="fa fa-phone"></i> +66 1234 5678</li>
        <li><i class="fa fa-envelope-o"></i> Batterry@gmail.com</li>
      </ul>
    </div>
    <div class="fl_right">
      <ul>
        <li><a href="#"><i class="fa fa-lg fa-home"></i></a></li>
        <li><a href="#">Login</a></li>
        <li><a href="#">Register</a></li>
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><a href="index1.html">BATMASTER</a></h1>
    </div>
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li class="active"><a href="index1.html">Home</a></li>
        <li><a class="drop" href="#">Pages</a>
          <ul>
            <li><a href="gallery.html">PORTFOLIO</a></li>
          </ul>
        </li>
        <li><a class="drop" href="https://www.loadgame-pc.com/">Download</a>
          <ul>
            <li>
              <ul>
              </ul>
            </li>
          </ul>
        </li>
      </ul>
    </nav>
    <!-- ################################################################################################ -->
  </header>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/74.jpg');">
  <div id="pageintro" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="flexslider basicslider">
      <ul class="slides">
        <li>
          <article>
            <h2 class="heading"> รวม 10 เกมน่าเล่นในปี 2018 ที่แฟนๆทั่วโลกต่างรอคอยกันมากที่สุด </h2>
            <footer>
              <ul class="nospace inline pushright">
              </ul>
            </footer>
          </article>
        </li>
          </article>
        </li>
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper coloured">
  <article class="hoc cta clear"> 
    <!-- ##############################################
	
	
	################################################## -->
    <h6 class="three_quarter first">รวม 10 เกมน่าเล่นในปี 2018 </h6>
    <footer class="one_quarter"><a class="btn" href="https://www.youtube.com/watch?v=A4ncpao1ej8&t=25s">Click here that &raquo;</a></footer>
    <!-- ################################################################################################ -->
  </article>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->

<div class="wrapper bgded" style="background-image:url('images/demo/backgrounds/02.jpg');"width="1280">
  <div class="hoc split clear">
    <section> 
      <!-- ################################################################################################ -->
      <p class="nospace font-xs">เกม 2018</p>
      <h6 class="heading">สุดยอดเกมแห่งปี</h6>
      <p class="btmspace-30">ทุกๆปีนั้นก็จะมีเกมระดับเทพออกมาให้เห็นกันอยู่แบบเรื่อยๆ โดยอย่างปีนี้ถ้าจะให้ยกตัวอย่างเกมสุดเทพเชื่อว่าคงหนีไม่พ้นเกมอย่าง Overwatch หรือ Battlefield 1 แต่ในบทความนี้เราจะแนะนำสุดยอดเกมที่ไม่ควรพลาดที่มีแผลนจะออกวางจำหน่ายในปี 2018 จะมีเกมอะไรกันบ้างในไปติดตามกันได้เลยครับผม.</p>
      <ul class="fa-ul">
        <li><i class="fa-li fa fa-check-circle"></i> กราฟิกขั้นสุดยอด</li>
        <li><i class="fa-li fa fa-check-circle"></i> ระบบเกมสมบูรณ์แบบ</li>
        <li><i class="fa-li fa fa-check-circle"></i> ครบในการเล่น</li>
      </ul>
      <!-- ################################################################################################ -->
    </section>
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="sectiontitle center">
      <h6 class="heading">[Game 2018]</h6>
      <p>แนะนำ 10 สุดยอดเกมระดับ AAA ที่ไม่ควรพลาดประจำปี 2018!!! มาครบทุกแนว ทุกเครื่อง</p>
    </div>
    <div class="clear">
      <div class="two_third first">
	  <h4 class="heading">1.Monster Hunter: World</h4>
      <h5 class="heading">Platform : PS 4 / Xbox one / PC </h5>
        <p>วางจำหน่าย 26 มกราคม 2018</p>
        <p class="btmspace-50">มากันที่เกมแรกที่จะออกมาต้อนรับเหล่า Gamer กันตั้งแต่เดือนแรกอย่าง Monster Hunter : world โดยเป็นการนำเกม Monster Hunter มาทำในรูปแบบ Openworld พร้อมกับเป็นการนำเหล่ามังกรจากภาคเก่าๆมารวมกันอยู่ในภาคนี้กันแบบจัดหนักจัดเต็ม และที่สำคัญที่ถือว่าเป็น Monster Hunter ภาคแรกที่ถูกลงให้กับเครื่อง PC อีกด้วย จึงทำให้น่าจับตามองอย่างยิ่งกว่าเกมนี้จะสามารถไปได้ถึงในระดับไหนจะสามารถโค่นแชมป์อย่าง Overwatch ได้หรือไม่</p>
      </div>
      <div class="one_third"><a href="http://www.monsterhunterworld.com/us/"><img class="inspace-10 btmspace-15 borderedbox" src="images/demo/11.jpg" alt=""></a>
    </div>
	<div class="clear">
      <div class="two_third first">
	  <h4 class="heading">2.Far Cry 5</h4>
      <h5 class="heading">Platform : PS 4 / Xbox one / PC </h5>
        <p>วางจำหน่าย 27 กุมภาพันธ์ 2018</p>
        <p class="btmspace-50">มากันที่เกมที่ 2 อย่าง Far Cry 5 สุดยอดเกม Openworld ที่ใครหลายๆคนกำลังรอคอย โดยภายในปีที่แล้วก็ได้ออกภาคใหม่มาอย่าง Far Cry : Primal ที่พาย้อนอดีตไปในยุคใดโนเสาร์มาแล้ว ส่วนเนื้อเรื่องในภาคนี้นั้นจะเกี่ยวข้อกับลัทธิหนึ่งที่มีความเป็นหัวรุนแรง และแน่นอนว่าตัวเอกของเรานั้นก็ดันไปติดอยู่ในที่แห่งนั้นอีกด้วย ภายในตัวอย่างที่เปิดตัวออกมาให้เราได้เห็นกันนั้น จะเห็นได้อย่างชัดเจนในเรื่องการพัฒนาในด้าน กราฟฟิกภาพที่สวยงามขึ้น ใครที่เป็นแฟนเกมนี้ละก็เก็บเงินรอกันได้เลยครับผม</p>
      </div>
      <div class="one_third"><a href="http://igg-games.com/far-cry-5-free-download-full-unlocked.html"><img class="inspace-10 btmspace-15 borderedbox" src="images/demo/12.jpg" alt=""></a>
    </div>
	<div class="clear">
      <div class="two_third first">
	  <h4 class="heading">3.Dragon Ball FighterZ</h4>
      <h5 class="heading">Platform : PS 4 / Xbox one / PC </h5>
        <p>วางจำหน่าย  ช่วง กุมภาพันธ์ 2018</p>
		<p class="btmspace-50">ใครที่เป็นแฟนคลับตัวยง กับ อนิเมะยุค 90 สุดมันส์อย่าง Dragon Ball ภายในปีนี้นั้นก็มีเกมภาคใหม่ออกมาให้เล่นกันด้วยนั้นก็คือ Dragon Ball FighterZ โดยเป็นซีรีย์ใหม่ล่าสุด ที่มีจุดเด่นในเรื่องการนำภาพ กราฟฟิค 2 ประเภทมารวมกันไว้ในที่เดียวกลายเป็น 2.5D นอกจากนั้นเรื่องกราฟฟิคก็ไม่ธรรมดาจากตัวอย่าง Game play ที่หลุดมานั้นตอนเล่นไม่ต่างอะไรกับการที่เรากำลังดูการต่อสู้ภายในอนิเมะ เลย แถมตัวละครก็ยกกันมาตั้งแต่ภาคแรกจนถึงภาคล่าสุด ใครที่เป็นแฟนเกม แฟนอนิเมะ แล้วละก็ไม่ควรพลาด</p>
      </div>
      <div class="one_third"><a href="https://www.bandainamcoent.com/games/dragon-ball-fighterz"><img class="inspace-10 btmspace-15 borderedbox" src="images/demo/13.jpg" alt=""></a>
    </div>
	<div class="clear">
      <div class="two_third first">
	  <h4 class="heading">4.A Way Out</h4>
      <h5 class="heading">Platform : PS 4 / Xbox one / PC </h5>
        <p>วางจำหน่าย ภายในปี 2018</p>
		<p class="btmspace-50">A Way Out เกมใหม่ล่าสุดที่เพิ่งเปิดตัวไปในช่วงกลางปีที่ผ่านมา โดยเกมนี้หลายๆคนอาจจะไม่คุ้นชื่อกันสักเท่าไหร่ แต่เป็นอีกหนึ่งเกมที่ได้รับแรงบรรดาลใจมาจาก ซีรีย์ยอดฮิต อย่าง Prison Break โดยเนื้อเรื่องภายในเกมนี้นั้นจะเกี่ยวข้องกับช่วงชีวิตของเหล่านักโทษที่ได้ทำการออกจากคุกมา ภายในเกมจะทำให้เราเห็นในทุกมุมมอง ทั้งในด้าน Action Drama และ มิตรภาพ ระหว่างเพื่อนทั้งสองคน จุดเด่นก็คือสามารถเล่นแบบ Co-op เนื้อเรื่องพร้อมกันได้ทั้งสองคน แถมจะเป็นการเล่นแบบแยกเนื้อเรื่องอีกด้วย แต่จะมีบางส่วนที่จะมาบรรจบกัน ใครที่กำลังหาเกมสนุกๆเล่นสักเกม จัดไว้ไม่เสียใจแน่นอน</p>
      </div>
      <div class="one_third"><a href="https://www.ea.com/games/a-way-out"><img class="inspace-10 btmspace-15 borderedbox" src="images/demo/14.jpg" alt=""></a>
    </div>
	<div class="clear">
      <div class="two_third first">
	  <h4 class="heading">5.Day Gone</h4>
      <h5 class="heading">Platform : PS 4 </h5>
        <p>วางจำหน่าย  ภายในปี 2018</p>
		<p class="btmspace-50">สุดยอดเกม Exclusive สำหรับเครื่อง Playstation 4 โดยเฉพาะอย่าง Day Gone เป็นอีกหนึ่งเกมที่ได้รับความสนใจในงานเปิดตัวในช่วงต้นปี 2016 อย่างมากเพราะด้วยเกมที่เป็นเนื้อเรื่องเกี่ยวกับซอบบี้พร้อมกับมีการเรนเดอร์ ซอมบี้ภายใน 1 ฉากที่มีมากกว่า 100 ตัว ดังนั้นใครที่เป็นคอบู้ละก็ พลาดไม่ได้ทั้งปวง และนอกจากจำนวนซอมบี้แล้ว อีกจุดหนึ่งที่น่าสนใจสำหรับเกมนี้คือในด้านเนื้อเรื่อง เพราะว่าเกมส่วนใหญ่ที่ออกแนวบู้ล้างพลาญขนาดนี้ เนื้อเรื่องมักไม่ค่อย Ok ดังนั้นเกมนี้จึงเป็นเกมที่น่าสนใจไม่น้อยเลยทีเดียวครับผม</p>
      </div>
      <div class="one_third"><a href="https://www.playstation.com/en-us/games/days-gone-ps4/"><img class="inspace-10 btmspace-15 borderedbox" src="images/demo/15.jpg" alt=""></a>
    </div>
	<div class="clear">
      <div class="two_third first">
	  <h4 class="heading">6.God Of War</h4>
      <h5 class="heading">Platform : PS 4</h5>
        <p>วางจำหน่าย  ภายในปี 2018</p>
		<p class="btmspace-50">มาถึงเกม Exclusive ที่น่าจับตามองมากที่สุดของ Playstation 4 ที่จะออกวางจำหนายภายในปี 2018 นี้ นั้นก็คือเกม God Of War นั้นเอง โดยเกมนี้ถือว่าเป็น เซอร์ไพรช์แบบจัดหนักเพราะว่าภายในเกม God Of War 4 นั้นเราจะได้เห็นว่าเครโทส ที่น่าจะตายไปแล้ว ดันกลับมา และ มาพร้อมกับลูกอีกหนึ่งคนด้วย แต่ดาบโซ่ประจำตัวของเขานั้นก็ได้เปลี่ยนไปใช้เป็นขวานแทน โดยภายในภาคนี้หลังจากที่ไปตบเทพ ซุส มาเป็นที่เรียบร้อย เป้าหมายต่อไปก็คือ เทพโอดิน ตัวเกมจะเป็นยังไงก็ต้องรอติดตามกันดูครับผม</p>
      </div>
      <div class="one_third"><a href="https://godofwar.playstation.com/"><img class="inspace-10 btmspace-15 borderedbox" src="images/demo/16.jpg" alt=""></a>
    </div>
	<div class="clear">
      <div class="two_third first">
	  <h4 class="heading">7.Spider Man</h4>
      <h5 class="heading">Platform : PS 4 </h5>
        <p>วางจำหน่าย ภายในปี 2018</p>
		<p class="btmspace-50">ต้องบอกก่อนว่าที่เห็นว่ามีเกม PS 4 ออกมาเยอะๆขนาดนี้นั้นเนืองจากทาง Sony เพิ่งจัดงาน  press conference  กันไปไม่นานโดยยกเกมเด็ดที่จะออกวางขายภายในปีหน้ามาให้เห็นกันก่อนใครโดยสำหรับเกม Spider Man นั้น เป็นอีกหนึ่งเกมที่น่าาสนใจเพราะว่าการกลับมาในรอบหลายปีของเกมตระกูล Spider Man โดยกราฟฟิกนั้นถือว่าเป็นจุดเด่นอย่างยิ่งสำหรับเกมนี้ นอกจากนั้น อีกส่วนสำคัญนั้นก็คือระบบการต่อสู้ที่ทำให้ใครหลายๆร้องว้าว เพราะสามารถหยิบใช้ของทุกๆอย่างภายในฉากมาเป็นอาวุธได้นั้นเอง</p>
      </div>
      <div class="one_third"><a href="http://www.spidermanhomecoming.com/discanddigital/"><img class="inspace-10 btmspace-15 borderedbox" src="images/demo/17.png" alt=""></a>
    </div>
	<div class="clear">
      <div class="two_third first">
	  <h4 class="heading">8.Shadow of the Colossus</h4>
      <h5 class="heading">Platforms : PS 4 </h5>
        <p>วางจำหน่าย ภายในปี 2018</p>
		<p class="btmspace-50">อีกหนึ่งเกมในตำนานที่น่าสนใจของเครื่อง Play Station 2 ที่ถูกนำมาปัดฝุ่นใหม่ให้สวยสดงดงามมากกว่าเดิม กราฟฟิกแบบใหม่ สำหรับเครื่อง Play Station 4 โดยเฉพาะ โดยเกมนี้จะมีจุดเด่นที่ศัตรูที่ขนาดใหญ่มาก การต่อสู้สุดอลังการ ที่ใครก็ตามที่ได้เห็นหรือได้เล่นจะสัมผัสได้ว่านี้แทบไม่ต่างกับฉากต่อสู้ภายในหนังเลย นอกจากนั้นเนื้อเรื่องที่กินใจสุดๆ พร้อมกับตอนจบสุดประทับใจ ใครที่อยากจะสัมผัสความรู้สึกแบบนี้กำเงินไว้ๆดีแล้วไปจัดกันได้ ภายในปีหน้า</p>
      </div>
      <div class="one_third"><a href="https://www.playstation.com/en-us/games/shadow-of-the-colossus-ps4/"><img class="inspace-10 btmspace-15 borderedbox" src="images/demo/18.jpg" alt=""></a>
    </div>
	<div class="clear">
      <div class="two_third first">
	  <h4 class="heading">9.Extinction</h4>
      <h5 class="heading">Platform : PS 4 / Xbox one / PC </h5>
        <p>วางจำหน่าย ช่วง มกราคม – เมษายน ปี 2018</p>
		<p class="btmspace-50">เกมนี้ชื่ออาจจะไม่คุ้นกันสักเท่าไหร่ แต่ถ้าใครที่รู้สึกคิดถึงเกมอย่าง Prince Of Persia แล้วละก็ให้เล็งเกมนี้กันไว้ได้เลย เพราะว่าเกมนี้่จะพาเราย้อนกับไปในธีมเดียวกันกับ Prince Of Persia แต่จะออกแนว Action มากกว่า แต่ศัตรูเราก็จะเป็นเหล่าปีศาจ หรือ เหล่า่เทพ ต่างๆมารวมกันไว้ โดยในตอนนี้ตัวเกมนั้นยังไม่ได้มีรายละเอียดอะไรออกมามากนัก แต่เกมนี้ก็จะออกมาให้เล่นกันในช่วงต้นปีหน้า ใครที่อยากเล่นเกมแนว Hack And Slash ก็เตรียมเงินกันไว้</p>
      </div>
      <div class="one_third"><a href="http://www.extinction.com/"><img class="inspace-10 btmspace-15 borderedbox" src="images/demo/19.jpg" alt=""></a>
    </div>
	<div class="clear">
      <div class="two_third first">
	  <h4 class="heading">10.State of Decay 2</h4>
      <h5 class="heading">Platform : Xbox One / PC </h5>
        <p>วางจำหน่าย  ช่วงกลางปี 2018</p>
		<p class="btmspace-50">State Of Decay เกมซีรีย์เอาตัวรอดจากฝูงซอมบี้ ที่ไม่ต่างอะไรกับเกมอย่าง Day Gone มากนักแต่จะเน้นไปในเรื่องการใช้อาวุธ ระยะประชิต และ ทรัพยากรอย่างจำกัด โดยในภาคแรกนั้นเกมที่เป็นที่นิยมในระดับหนึ่งแต่ก็ไม่ได้ ปัง มากอย่างที่ควรเนื่องด้วยเกมที่เป็นแบบนี้ ควรที่จะเป็นเกมออนไลน์ มากกว่า ดังนั้นในภาคที่ 2 ที่จะออกในปี 2018 นีจึงเป็นเกมที่น่าสนใจอย่างยิ่งเพราะเขาได้นำระบบ Co-op ที่สามารถเล่นด้วยกันได้มากสุดถึง 4 คน ดังนั้นใครเพื่อนเยอะก็รวมตัวกันได้เลย

</p>
      </div>
      <div class="one_third"><a href="https://www.stateofdecay.com/age-gate/?r=%2F"><img class="inspace-10 btmspace-15 borderedbox" src="images/demo/20.jpg" alt=""></a>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
    <div class="clear"></div>
  </main>
</div
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper bgded overlay" style="background-image:url('images/demo/66.jpg');">
  <div id="testimonial" class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <blockquote>และนี่คือ 10 เกมที่น่าจับตามองภายในปี 2018กระแสของเกมก็ยังงดำเนินไปได้อย่างสุดยอดเหมือนเดิมและมีแนวโน้มที่จะพัฒนาต่อไปเรื่อยๆด้วย  </blockquote>
    <figure><a href="gallery.html"><img class="circle" src="images/demo/22.jpg" alt=""></a>
      <figcaption><strong>Bat</strong><br>
        <em>arai, mai ru</em></figcaption>
    </figure>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <section class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <h6 class="heading">เรื่องอื่นๆเกี่ยวกับ GAME 2018</h6>
    <div class="group latest">
      <article class="one_third first">
        <figure><a href="https://notebookspec.com/they-shall-not-pass-dlc-battlefield-1-get-free-in-origin-now/438964/"><img src="images/demo/30.jpg" alt=""></a>
          <figcaption>
            <time datetime="2045-04-06T08:15+00:00"><strong>03</strong> <em>May</em></time>
          </figcaption>
        </figure>
        <div class="txtwrap">
          <h4 class="heading">Battlefield 1: They Shall Not Pass</h4>
          <ul class="nospace meta">
            <li>by <a href="#">Admin</a></li>
            <li>in <a href="#">Chanthimatorn</a></li>
          </ul>
          <p>ข่าวดีสำหรับคอเกม Battlefield 1 ที่กำลังจะสอบ DLC เสริมอย่าง They Shall Not Pass ครับเพราะล่าสุดบน Origin ได้เปิดให้เราได้สอย DLC ตัวนี้ฟรีไม่คิดเงินโดยมีระยะเวลาแจกที่สองสัปดาห์ครับ&hellip;</p>
          <footer><a href="https://notebookspec.com/they-shall-not-pass-dlc-battlefield-1-get-free-in-origin-now/438964/">Read More &raquo;</a></footer>
        </div>
      </article>
      <article class="one_third">
        <figure><a href="https://notebookspec.com/pes-2019-leak-first-detail-game/438852/"><img src="images/demo/31.jpg" alt=""></a>
          <figcaption>
            <time datetime="2045-04-05T08:15+00:00"><strong>02</strong> <em>May</em></time>
          </figcaption>
        </figure>
        <div class="txtwrap">
          <h4 class="heading">Pro Evolution Soccer 2019</h4>
          <ul class="nospace meta">
            <li>by <a href="#">Admin</a></li>
            <li>in <a href="#">Chanthimatorn</a></li>
          </ul>
          <p>ได้มีข้อมูลหลุดของเกมฟุตบอลแห่งยุค PES 2019 หรือ Pro Evolution Soccer 2019 ออกมาเป็นครั้งแรกแล้วโดย PlayStation Store จากฮ่องกงที่ปล่อยข้อมูลหลุดออกมาว่าในภาค 2019 เราจะได้พบกับการยกเครื่องระบบเกมครั้งใหม่และลิขสิทธิ์จากทีมลีคใหญ่เข้ามาเพิ่มเติมด้วย&hellip;</p>
          <footer><a href="https://notebookspec.com/pes-2019-leak-first-detail-game/438852/">Read More &raquo;</a></footer>
        </div>
      </article>
      <article class="one_third">
        <figure><a href="https://notebookspec.com/payday-2-free-play-limit-time-and-discount-game-50-percent/438492/"><img src="images/demo/33.jpg" alt=""></a>
          <figcaption>
            <time datetime="2045-04-04T08:15+00:00"><strong>26</strong> <em>Apr</em></time>
          </figcaption>
        </figure>
        <div class="txtwrap">
          <h4 class="heading">Payday 2</h4>
          <ul class="nospace meta">
            <li>by <a href="#">Admin</a></li>
            <li>in <a href="#">Chanthimatorn</a></li>
          </ul>
          <p>Payday 2 เป็นอีกหนึ่งเกมที่ควรหามาเล่นให้ได้และถ้าใครคิดว่าอยากจะลองเล่นแต่ไม่มีเงินซื้อเกมเลยช่วงเวลานี้ถือว่าเป็นโอกาสที่ดีแล้วที่จะได้ลองเพราะตัวเกมได้เปิดให้เล่นฟรีเป็นเวลา 3 วันบน Steam และโปรโมชั่นพิเศษลดราคาสำหรับคนที่อยากได้เกมไปเล่นถาวร&hellip;</p>
          <footer><a href="https://notebookspec.com/payday-2-free-play-limit-time-and-discount-game-50-percent/438492/">Read More &raquo;</a></footer>
        </div>
      </article>
    </div>
    <!-- ################################################################################################ -->
  </section>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 
    <!-- ################################################################################################ -->
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
        <li><a class="faicon-dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
        <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
        <li><a class="faicon-google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
        <li><a class="faicon-vk" href="#"><i class="fa fa-vk"></i></a></li>
      </ul>
    </div>
    
  
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2016 - All Rights Reserved - <a href="#">Domain Name</a></p>
    <p class="fl_right">Template by <a target="_blank" href="http://www.os-templates.com/" title="Free Website Templates">OS Templates</a></p>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script>


</body>
</html>